# FEEDBACK
---
Thank you for your team project submission.                  Please see below for your scores and feedback.
---
## Your Github Repo URL: https://github.ncsu.edu/csc510-s2022/CSC510-1 
| ITEM | SCORE | FEEDBACK |
| --- | --- | --- |
| **DEPLOY SCRIPTS + SCREENCAST** | 30.0/30 | Well done. You have a good deploy scripts + screencast. |
| **EXPLORATORY TESTING** | 30.0/30 | Great job! Exploratory testing passed! |
| **ACCEPTANCE TESTING** | 40.0/40 | Great job! Acceptance testing passed! |
| --- | --- | --- |
| **Total** | 100.0/100 |  |

If you notice any errors, please let us know [by using the regrade request form](https://github.ncsu.edu/CSC-510/Course/blob/main/README.md#homeworkproject-regrade-requests).
