# Repo Rewards

## Authors

Anna Crosby <kacrosby@ncsu.edu>  
Cristina Ramirez <ceramire@ncsu.edu>  
Jack Lanois <jrlanois@ncsu.edu>  
Trevor Brennan <tsbrenna@ncsu.edu>  

# Design Doc
The design doc can be found here: [https://github.ncsu.edu/csc510-s2022/CSC510-1/blob/main/Design.md](https://github.ncsu.edu/csc510-s2022/CSC510-1/blob/main/Design.md)
