class GenericChatApi {

    constructor() {
        this.callback = null;
    }
    
    register_callback(callback) {
        console.error("Not implemented yet...");
    }
}

const factory = {
    GenericChatApi
}

module.exports = factory;
