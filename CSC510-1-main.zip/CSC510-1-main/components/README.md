# Abstract

This directory contains the various main components of the project. Each
component either has its own file if it is expected to be fairly contained, or
it has an additional directory if it is expected to have multiple
implementations.
