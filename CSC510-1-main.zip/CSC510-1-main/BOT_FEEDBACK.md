# FEEDBACK
---
Thank you for your team project submission.                  Please see below for your scores and feedback.
---
## Your Github Repo URL: https://github.ncsu.edu/csc510-s2022/CSC510-1 
| ITEM | SCORE | FEEDBACK |
| --- | --- | --- |
| <tr><th colspan=3> Setup </th></tr> |
| **BOT Platform Implmentation** | 20.0/20 | 3 use cases implemented. Good job. Looking forward to the higher coverage in chat_composer.js |
| **Use Case Refinement** | 10.0/10 | No concern about use cases |
| **Mocking** | 30.0/30 | Mocking present and properly used |
| **Testing** | 30.0/30 | Stmt Code coverage: 93.61# of test cases: 49All passing tests.Great test coverage.Proper use of expect/assert. |
| **Screencast** | 10.0/10 | Good Job. |
| --- | --- | --- |
| **Total** | 100.0/100 |  |

If you notice any errors, please let us know [by using the regrade request form](https://github.ncsu.edu/CSC-510/Course/blob/main/README.md#homeworkproject-regrade-requests).
