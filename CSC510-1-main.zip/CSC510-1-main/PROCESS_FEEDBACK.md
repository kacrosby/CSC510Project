# FEEDBACK
---
Thank you for your team project submission.                  Please see below for your scores and feedback.
---
## Your Github Repo URL: https://github.ncsu.edu/csc510-s2022/CSC510-1 
| ITEM | SCORE | FEEDBACK |
| --- | --- | --- |
| **PROCESS** | 25.0/25 | Well done. You have a good process. |
| **PRACTICES** | 17.9/25 | Suggestions to improve your practices:<br>*  has a "reflection" section in Process.md for Scrum1, not for Scrum 2<br/>*  Don't see any core or Corollary practice identified and documented in Process.md<br/>*  Scrum meeting 1 notes maintained in Process.md, Scrum meeting 2 notes I don't see<br/> |
| **CONSISTENCY** | 25.0/25 | Well done. Your team has sufficient consistency. |
| **DEMO / SIGNOFF to TAs** | 25.0/25 | Well done on the demo. |
| --- | --- | --- |
| **Total** | 92.86/100 |  |

If you notice any errors, please let us know [by using the regrade request form](https://github.ncsu.edu/CSC-510/Course/blob/main/README.md#homeworkproject-regrade-requests).
