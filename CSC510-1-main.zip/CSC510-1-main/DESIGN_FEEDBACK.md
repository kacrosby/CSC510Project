# FEEDBACK
---
Thank you for your team project submission.                  Please see below for your scores and feedback.
---
## Your Github Repo URL: https://github.ncsu.edu/csc510-s2022/CSC510-1 
| ITEM | SCORE | FEEDBACK |
| --- | --- | --- |
| <tr><th colspan=3> Setup </th></tr> |
| **Problem Stmt** | 15.0/15 | good job! |
| **Bot Description** | 10.0/10 | good job! |
| **Use Cases** | 15.0/15 | NOTE THIS IS FEEDBACK YOU PREVIOUSLY RECEIVED<br /><br />No concerns about your use cases.  Well done.  Please proceed with Bot.md |
| **Wireframes** | 15.0/15 | good job! |
| **Storyboard** | 12.5/15 | Storyboard should be more story-like and clearly highlight what problem the user is facing and how your bot will solve it. |
| **Architecture + Additional Patterns** | 25.0/30 | Architecture design looks good overall but could use more explicit detail about what platforms you'll be using for each aspect of your bot. Additional patterns look good. |
| --- | --- | --- |
| **Total** | 92.5/100 |  |

If you notice any errors, please let us know [by using the regrade request form](https://github.ncsu.edu/CSC-510/Course/blob/main/README.md#homeworkproject-regrade-requests).
