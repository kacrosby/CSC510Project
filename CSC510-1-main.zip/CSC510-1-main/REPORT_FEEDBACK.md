# FEEDBACK
---
Thank you for your team project submission.                  Please see below for your scores and feedback.
---
## Your Github Repo URL: https://github.ncsu.edu/csc510-s2022/CSC510-1 
| ITEM | SCORE | FEEDBACK |
| --- | --- | --- |
| **PRESENTATION** | 16.2/25 | I think the entertainment factor might have overshadowed the content that the video was intended to convey.   Was hoping for more motivation of the problem and technical details. |
| **PEER PRESENTATION EVALUATIONS** | 10.0/10 | (If you did 4 or more, your bonus will be on your individual moodle grade.) |
| **REPORT** | 15.0/15 |  |
| **360 PEER EVALUATION** | 50.0/50 | (If your moodle score is significantly lower than your team score, you might not have submitted a 360 peer evaluation.) |
| --- | --- | --- |
| **Total** | 91.25/100 |  |

If you notice any errors, please let us know [by using the regrade request form](https://github.ncsu.edu/CSC-510/Course/blob/main/README.md#homeworkproject-regrade-requests).
