# Abstract

This directory is intended to store the logic necessary to allow users to
configure this bot to their needs. It will contain a set of defaults, as well
as mechanisms to overwrite those defaults with the desired values.
