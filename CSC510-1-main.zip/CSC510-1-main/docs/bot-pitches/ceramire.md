## Issue Reward Bot ##

GitHub collaborators don’t get enough recognition when closing project issues, especially those issues of bug reports that no one wants to take care of. Issue Reward Bot will recognize every time a collaborator closes a bug issue, by sending him a congratulation/keep it up/kudos message. It will also have standings among the collaborators, showing who has closed the most bug issues. At the end of a certain period (a week, every other week, a month), it will send everyone in the team a message congratulating the 1st, 2nd, and 3rd place. This bot will create a competition to close bug issues among collaborators and it will probably increase their productivity. With the use of Issue Reward Bot, the project will have less opened bug issues and happier team members.


Tagline: Less Bugs, More Smiles
